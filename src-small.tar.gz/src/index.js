import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
// import $ from "jquery";
import App from './App';
import App2 from './App2'
import File from './file.json';
// import webticker from './jquery.webticker.min.js';
import registerServiceWorker from './registerServiceWorker';

// document.domain = "mysite.com";

// window.$ = window.jQuery = require('jquery');

var cont=File[0].address;


const silly=
  (

  <div>
    <span>

    <table id="project_id" style={{margin: '45px', border : '5px solid red', height : '475px', width : '1800px'}}>
      <th>CASE</th>
          <tbody>
            Permit number: <ti>{cont}</ti><br/>
            Description: <ti>description</ti><br/>
            <br/>
            <br/>
            Address: <ti>address</ti><br/>
            <br/>
            <br/>
            Category: <ti>category</ti><br/>
            Sub-category: <ti>usesAndscopes</ti><br/>
            Value: $<ti>subPermitValue</ti><br/>
            Application date: <ti>applied</ti><br/>
            <span>approved <ti>Application approved: approved</ti></span>
            <span>approved <br/></span>
            <span>issued <ti>Permit issued: issued</ti></span>
            <span>issued <br/></span>
            <span>newUnits <ti>New units: newUnits</ti></span>
            <span>newUnits <br/></span>
            <span>reUnits <ti>Remodeled unitsreUnits</ti></span>
            <span>reUnits <br/></span>
            <span>affordableUnits <ti>Affordable housing units: affordableUnits</ti></span>
            <span>affordableUnits <br/></span>
            <span>newSquareFeet <ti>Square feet added: newSquareFeet</ti></span>
            <span>newSquareFeet <br/></span>
            <span>reSquareFeet <ti>Remodeled sqaure feet: reSquareFeet</ti></span>
            <span>reSquareFeet <br/></span>
            Applicant Name: <ti>primaryLast}</ti><br/>
            <span>primaryCompany <ti>Company: primaryCompany}</ti>}</span>
            <span>primaryCompany <br/>}</span>
            Owner: <ti>owner1Last}</ti><br/>
            <span>owner1Company <ti>Company: owner1Company}</ti></span>
            <span>owner1Company <br/>}</span>
      </tbody>
    </table>
    </span>
  </div>)


  ReactDOM.render(<App/>, document.getElementById('root'));
  console.log(ReactDOM.findDOMNode(document.getElementById('root')))
  // ReactDOM.render(silly, document.getElementById('root'));
registerServiceWorker();
