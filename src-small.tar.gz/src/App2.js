import React, { Component } from 'react';
import File from './file.json';
// import $ from 'jquery';
// import webticker from './jquery.webticker.min.js';
import './App.css';

window.$ = window.jQuery = require('jquery');

export default class App extends Component {

    // componentDidMount() {
    //
    //   var cases = File.map(function(caseOnPoint){
    //     return ({caseOnPoint});
    //   })
    //
    //   console.log({cases})
    //
    //   this.cases[1].cases = cases;
    // }
    //
    componentDidUpdate(){
      console.log('hewow');
    }

    render() {

        var items = File.map(function (item, index) {
          // Any time you construct a list of elements or components,
          // you need to set the `key` so React can more easily work
          // with the DOM.
          var crap = (index+'-position').toString();
          var crack;

          console.log(crap+' and '+ this.nextPosition);

          if (index===this.nextPosition){
            crack='selected';
            }


          return (<span><li id={crack} style = {{border: '1px solid black', width: '11em'}} key={index}>{item}</li></span>);
        })
      // console.log({items});

      return (<div><script src="./jquery.webticker.min.js"></script>{items}</div>)

      //
      // // console.log(this.cases[1].cases);
      //
      // var cases = File.map(function(caseOnPoint){
      //   return caseOnPoint;
      // })
      //
      // console.log({cases})
      //
      // this.cases = cases;
      //
      // // var blurb=this.cases[1].cases[0];
      //
      // console.log(this.cases[1]);
      // // console.log({File} + 'I was triggered during render')
      // return (
      //   <div>
      //     <table id="project_id" style={{margin: '45px', border : '5px solid red', height : '475px', width : '1800px'}}>
      //       <th>CASE</th>
      //           <tbody>
      //             Permit number: <ti>{this.cases[1].number}</ti><br/>
      //             Description: <ti>{this.cases[1].description}</ti><br/>
      //             <br/>
      //             <br/>
      //             Address: <ti>{this.cases[1].address}</ti><br/>
      //             <br/>
      //             <br/>
      //             Category: <ti>{this.cases[1].category}</ti><br/>
      //             Sub-category: <ti>{this.cases[1].usesAndscopes}</ti><br/>
      //             Value: $<ti>{this.cases[1].subPermitValue}</ti><br/>
      //             Application date: <ti>{this.cases[1].applied}</ti><br/>
      //             <span>{this.cases[1].approved && <ti>Application approved: {this.cases[1].approved}</ti>}</span>
      //             <span>{this.cases[1].approved && <br/>}</span>
      //             <span>{this.cases[1].issued && <ti>Permit issued: {this.cases[1].issued}</ti>}</span>
      //             <span>{this.cases[1].issued && <br/>}</span>
      //             <span>{this.cases[1].newUnits !== 0 && <ti>New units: {this.cases[1].newUnits}</ti>}</span>
      //             <span>{this.cases[1].newUnits !== 0 && <br/>}</span>
      //             <span>{this.cases[1].reUnits !== 0 && <ti>Remodeled units{this.cases[1].reUnits}</ti>}</span>
      //             <span>{this.cases[1].reUnits !== 0 && <br/>}</span>
      //             <span>{this.cases[1].affordableUnits !== 0 && <ti>Affordable housing units: {this.cases[1].affordableUnits}</ti>}</span>
      //             <span>{this.cases[1].affordableUnits !== 0 && <br/>}</span>
      //             <span>{this.cases[1].newSquareFeet !== 0 && <ti>Square feet added: {this.cases[1].newSquareFeet}</ti>}</span>
      //             <span>{this.cases[1].newSquareFeet !== 0 && <br/>}</span>
      //             <span>{this.cases[1].reSquareFeet !== 0 && <ti>Remodeled sqaure feet: {this.cases[1].reSquareFeet}</ti>}</span>
      //             <span>{this.cases[1].reSquareFeet !== 0 && <br/>}</span>
      //             {/* <ti>{this.cases[1].primaryFirst}</ti><br/> */}
      //             Applicant Name: <ti>{this.cases[1].primaryLast}</ti><br/>
      //             <span>{this.cases[1].primaryCompany && <ti>Company: {this.cases[1].primaryCompany}</ti>}</span>
      //             <span>{this.cases[1].primaryCompany && <br/>}</span>
      //             {/* <ti>{this.cases[1].contractorFirst}</ti><br/> */}
      //             {/* <ti>{this.cases[1].contractorLast}</ti><br/> */}
      //             {/* <ti>{this.cases[1].contractorCompany}</ti><br/> */}
      //             {/* <ti>{this.cases[1].owner1First}</ti><br/> */}
      //             Owner: <ti>{this.cases[1].owner1Last}</ti><br/>
      //             <span>{this.cases[1].owner1Company && <ti>Company: {this.cases[1].owner1Company}</ti>}</span>
      //             <span>{this.cases[1].owner1Company && <br/>}</span>
      //             {/* <ti>{this.cases[1].owner2First}</ti><br/> */}
      //             {/* <ti>{this.cases[1].owner2Last}</ti><br/> */}
      //             {/* <ti>{this.cases[1].owner2Company}</ti><br/> */}
      //       </tbody>
      //     </table>
      //   </div>
      // )
    }
}
